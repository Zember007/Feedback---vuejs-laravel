<script setup lang="ts">
    import Sidebar from '@/Components/Dashboard/Sidebar.vue';
    import Header from '@/Components/Dashboard/Header.vue';

</script>

<template>
  <div class="flex h-screen bg-gray-200 font-roboto">
    <Sidebar />

    <div class="flex-1 flex flex-col overflow-hidden">
      <Header />

      <main class="flex-1 overflow-x-hidden overflow-y-auto bg-sky-50">
        <div class="container mx-auto px-6 py-8">
          <slot />
        </div>
      </main>
    </div>
  </div>
</template>
