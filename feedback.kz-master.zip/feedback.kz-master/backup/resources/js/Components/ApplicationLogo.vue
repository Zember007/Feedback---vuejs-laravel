<template>
    <img class="" src="../../img/FeedLogoMin.png" alt="Feedback.kz">
</template>
